from os import walk
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.cm as cm
#%matplotlib inline
#import theano
#import theano.tensor as T
#from theano.tensor.nnet.neighbours import images2neibs
from PIL import Image
#import image class
#code from here
import glob

def eigenface():
    imageFolderPath = "faceapp/jaffe"
    imagePath = glob.glob(imageFolderPath + "/*.tiff")
    no_images = len(imagePath)
    Ims = np.empty([no_images,256,256])

    for i in range(no_images):
        im = np.asarray(Image.open(imagePath[i]))
        Ims[i] = im
    X = np.reshape(Ims,[213,65536])
    X = X.T

    psi = X.mean(1)
    Psi_reshaped = np.reshape(psi,[256,256])
    psi_face = Image.fromarray(Psi_reshaped)
    psi_face.show()
    #psi_face.save("*.bmp")


    plt.imshow(Psi_reshaped,cmap = cm.Greys_r)
    plt.show()

    Psi = np.repeat(np.reshape(psi,[65536,1]),no_images,axis=1)

    Fi = X - Psi
    A = Fi
    C = np.dot(A.T,A)
    #print C.shape
    w,v = np.linalg.eigh(C)
    # eigenvalue w is in ascending order, so the larger value is in the bottom
    V = np.fliplr(v)
    left = np.dot(C,v[:,0])
    right = np.dot(w[0],v[:,0])


    M = no_images
    V_M = V
    U = np.dot(A,V_M)
    U_sum = np.sum(U,axis = 0)
    U_sum = np.repeat(np.reshape(U_sum,[1,M]),65536,axis=0)
    #print U_sum.shape
    #U_normalized_temp = U
    U_normalized = np.divide(U,U_sum)
    #print U_normalized.shape

    for i in range(5):

        eig_matrix1 = np.reshape(U[:,i],[256,256])
        eig_matrix2 = np.ones([256,256])

        #eig_matrix = eig_matrix2 - eig_matrix1
        eig_face = Image.fromarray(eig_matrix1)
        eig_face.show()