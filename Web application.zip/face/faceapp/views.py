from django.shortcuts import render
import bigdata

def index(request):
    return render(request, 'index.html')


def calculate(request):
    bigdata.eigenface()

    return render(request, 'result.html')